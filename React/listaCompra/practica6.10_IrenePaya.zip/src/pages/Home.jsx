import "./home.css";
const Home = () => {
	return <h1>Booky, tu tienda favorita de libros.</h1>;
};

export default Home;
