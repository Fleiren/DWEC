const Content = (props) => {
	return <div className="Content_container">{props.children}</div>;
};

export default Content;
