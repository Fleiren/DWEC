import React, { createContext, useState } from "react";

const messageContext = createContext();

const MessageProvider = ({ children }) => {
	const [message, setMessage] = useState("");
	//Reutilizo el contexto de mensajes que hice en la práctica de discos.
	const MESSAGE_TYPES = {
		OK: "OK",
		ERROR: "ERROR",
		INFO: "INFO",
		WARNING: "WARNING",
	};
	// Se utilizaría de manera opcional para el diseño del mensaje.
	const [messageType, setMessageType] = useState(MESSAGE_TYPES.INFO);
	const [isActive, setIsActive] = useState(false);

	//Como es opcional la función de añadir un tipo de mensaje, por defecto sera INFO.
	const showMessage = (newMensaje, type = "info") => {
		setMessage(newMensaje);
		switch (type.toLowerCase()) {
			case "exito":
				setMessageType(MESSAGE_TYPES.OK);
				break;
			case "error":
				setMessageType(MESSAGE_TYPES.ERROR);
				break;
			case "warning":
				setMessageType(MESSAGE_TYPES.WARNING);
				break;
			default:
				setMessageType(MESSAGE_TYPES.INFO);
		}
		setIsActive(true);
		setTimeout(() => {
			hideMessage();
		}, 3000);
	};

	const hideMessage = () => {
		setMessage("");
		setMessageType(MESSAGE_TYPES.INFO);
		setIsActive(false);
	};

	const dataProvider = {
		message,
		messageType,
		isActive,
		showMessage,
		hideMessage,
	};
	return (
		<messageContext.Provider value={dataProvider}>
			{children}
		</messageContext.Provider>
	);
};

export default MessageProvider;
export { messageContext };
