const ShoppingList = () => {
	return <h1>Lista de la compra</h1>;
};

export default ShoppingList;
