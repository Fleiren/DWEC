const ProductList = () => {
	return <h1>Lista de productos</h1>;
};

export default ProductList;
