const Container = (props) => {
	return <div className="Container_container">{props.children}</div>;
};

export default Container;
