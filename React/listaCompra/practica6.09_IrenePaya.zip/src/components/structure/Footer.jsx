import "./footer.css";
const Footer = () => {
	return (
		<footer className="footer_container">
			<small>Derechos reservados a Irene Payá Hernández.</small>
		</footer>
	);
};

export default Footer;
