"use strict";
import { cambiarFondoParrafo } from "./biblioteca/ejercicio3.js";

setInterval(() => {cambiarFondoParrafo()}, 1000);